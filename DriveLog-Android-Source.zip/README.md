# DriveLog Android app

DriveLog is an Android Studio project for recording supervised practice drives. It includes an in-app OpenStreetMap map, background GPS route recording, start/end timestamps, duration, GPS speed, distance, night-hour totals, a configurable goal, practice prompts, Google Maps handoff, and a printable PDF report.

## Build the APK

This workspace does not include Android SDK or Gradle build tools, so it cannot produce or test a signed APK here. To build on a computer with Android Studio:

1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 if prompted.
3. Let Gradle sync, then choose Build > Build APK(s).
4. Android Studio writes the debug APK to app/build/outputs/apk/debug/app-debug.apk.
5. Transfer that APK to the Android phone and install it. Android may ask you to allow installs from that source.

The project uses Java 17 and Android Gradle Plugin 8.6.1. The map uses OpenStreetMap tiles and needs an internet connection. The Google Maps button opens Google Maps for the current or last GPS point.

## Use safely

- Set the goal and supervising adult before moving the vehicle.
- Start and stop a trip while parked, then keep the phone put away.
- Allow precise location and notification permissions so background route recording can run.
- At the end, park and stop the drive. Only count entries confirmed by the supervising adult.
- At export, choose Save as PDF in Android's print screen.

## Illinois export

The report lists practice date and time, duration, a night-hours designation, supervising adult, speed and distance, followed by timestamped GPS route points and a signature area. It is organized as a supporting record for Illinois' current 50-Hour Practice Driving Log (DSD X 152). It is not state-issued or state-approved, so it should not be represented as a replacement for the current official form. The supervising adult should verify and sign the record and transfer totals to DSD X 152 if the Secretary of State requests that form.

Illinois' under-18 requirement is generally 50 hours, including 10 hours at night, with qualifying supervision. Confirm the current requirements with a parent or guardian and the Illinois Secretary of State before filing.

## Notes

- Data stays in app-private storage on this device; there is no account or upload service.
- GPS quality varies, and speed is derived from GPS, not the vehicle speedometer.
- Android may stop background location if the user force-stops the app or disables location.
- Maps and tile services may be unavailable offline.
