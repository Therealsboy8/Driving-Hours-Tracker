package com.drivelog.app;

import android.Manifest;
import android.app.Activity;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler();
    private static final int PERMS = 42;
    private boolean printAfterLoad = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                if (printAfterLoad) { printAfterLoad = false; handler.postDelayed(() -> printReport(), 650); }
            }
        });
        web.addJavascriptInterface(new Bridge(), "DriveLog");
        web.loadUrl("file:///android_asset/index.html");
        requestPermissionsIfNeeded();
        handler.postDelayed(poll, 1000);
    }

    private void requestPermissionsIfNeeded() {
        java.util.ArrayList<String> missing = new java.util.ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), PERMS);
    }
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (web != null) web.evaluateJavascript("window.onNativeState && window.onNativeState(" + getStateJson() + ")", null);
            handler.postDelayed(this, 2500);
        }
    };
    private SharedPreferences prefs() { return getSharedPreferences("drivelog", MODE_PRIVATE); }
    private JSONObject readJson(String key, JSONObject fallback) {
        try { return new JSONObject(prefs().getString(key, fallback.toString())); } catch (Exception e) { return fallback; }
    }
    private String getStateJson() {
        JSONObject s = new JSONObject();
        try {
            s.put("goalHours", prefs().getInt("goalHours", 50));
            s.put("trips", new JSONArray(prefs().getString("trips", "[]")));
            s.put("active", readJson("active", new JSONObject()));
        } catch (Exception ignored) {}
        return s.toString();
    }
    private void tell(String message) { runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }
    private class Bridge {
        @JavascriptInterface public String state() { return getStateJson(); }
        @JavascriptInterface public void setGoal(int hours) {
            prefs().edit().putInt("goalHours", Math.max(1, Math.min(200, hours))).putBoolean("setupDone", true).apply();
        }
        @JavascriptInterface public boolean isSetupDone() { return prefs().getBoolean("setupDone", false); }
        @JavascriptInterface public void startTrip(String supervisor, boolean night) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                tell("Allow location access, then start your trip while parked."); requestPermissionsIfNeeded(); return;
            }
            if (!prefs().getString("active", "{}").equals("{}")) { tell("A trip is already recording."); return; }
            try {
                JSONObject active = new JSONObject();
                active.put("startMs", System.currentTimeMillis());
                active.put("supervisor", supervisor == null ? "" : supervisor);
                active.put("night", night);
                active.put("points", new JSONArray());
                prefs().edit().putString("active", active.toString()).apply();
                Intent i = new Intent(MainActivity.this, TrackingService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            } catch (Exception e) { tell("Couldn't start this trip."); }
        }
        @JavascriptInterface public void stopTrip() {
            stopService(new Intent(MainActivity.this, TrackingService.class));
        }
        @JavascriptInterface public void exportPdf(String encodedHtml) {
            try {
                String html = new String(Base64.getDecoder().decode(encodedHtml), "UTF-8");
                runOnUiThread(() -> { printAfterLoad = true; web.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null); });
            } catch (Exception e) { tell("Couldn't create the report."); }
        }
        @JavascriptInterface public void openGoogleMaps(double lat, double lon) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + lat + "," + lon));
                startActivity(i);
            } catch (Exception e) { tell("Google Maps couldn't be opened."); }
        }
    }
    private void printReport() {
        if (Build.VERSION.SDK_INT < 19) { tell("PDF export needs Android 4.4 or newer."); return; }
        PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
        PrintDocumentAdapter adapter = web.createPrintDocumentAdapter("DriveLog-Illinois-50-Hour-Log");
        PrintJob job = pm.print("DriveLog Illinois Practice Log", adapter, null);
        tell("Choose Save as PDF in the print screen to save or share the log.");
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(poll);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
