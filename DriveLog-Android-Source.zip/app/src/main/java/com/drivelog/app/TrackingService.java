package com.drivelog.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;

public class TrackingService extends Service implements LocationListener {
    private static final String CHANNEL = "driving_trip";
    private LocationManager lm;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("DriveLog is recording")
                .setContentText("Trip tracking continues in the background. Please keep your phone put away.")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentIntent(pi).setOngoing(true).build();
        startForeground(51, n);
        lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 8, this, Looper.getMainLooper());
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 15, this, Looper.getMainLooper());
                Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) onLocationChanged(last);
            }
        } catch (Exception ignored) {}
    }
    private android.content.SharedPreferences prefs() { return getSharedPreferences("drivelog", MODE_PRIVATE); }
    private JSONObject getActive() {
        try { return new JSONObject(prefs().getString("active", "{}")); } catch (Exception e) { return new JSONObject(); }
    }
    @Override public void onLocationChanged(Location loc) {
        if (loc == null || !loc.hasAccuracy() || loc.getAccuracy() > 80) return;
        JSONObject a = getActive();
        if (!a.has("startMs")) return;
        try {
            JSONArray points = a.optJSONArray("points");
            if (points == null) points = new JSONArray();
            JSONObject p = new JSONObject();
            p.put("lat", loc.getLatitude()); p.put("lon", loc.getLongitude());
            p.put("time", loc.getTime()); p.put("speed", loc.hasSpeed() ? loc.getSpeed() * 2.236936 : 0);
            p.put("accuracy", loc.getAccuracy());
            if (points.length() == 0 || loc.getTime() - points.getJSONObject(points.length()-1).optLong("time") >= 2500) points.put(p);
            a.put("points", points);
            prefs().edit().putString("active", a.toString()).apply();
        } catch (Exception ignored) {}
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (lm != null) lm.removeUpdates(this);
        JSONObject a = getActive();
        if (a.has("startMs")) {
            try {
                a.put("endMs", System.currentTimeMillis());
                JSONArray trips = new JSONArray(prefs().getString("trips", "[]"));
                trips.put(a);
                prefs().edit().putString("trips", trips.toString()).putString("active", "{}").apply();
            } catch (Exception ignored) {}
        }
        stopForeground(true);
        super.onDestroy();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Trip tracking", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public void onProviderEnabled(String p) {}
    @Override public void onProviderDisabled(String p) {}
    @Override public void onStatusChanged(String p, int s, Bundle b) {}
    @Override public IBinder onBind(Intent i) { return null; }
}
